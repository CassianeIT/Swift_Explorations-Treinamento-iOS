/*:
## Solução do FizzBuzz com Switch Case
 
 Uma boa alternativa para solucionar o enigma é utilizando switch e, naturalmente, um loop também:
 
 */
// Codifique aqui sua solução

//Escreva um programa que imprima os números de 1 a 100

//for index in 1...100 {
//    switch index <= 100 {
//    case true:
// print (index)
//    default:
//        print("sei la")
//    }
//}

//Para números divisíveis por 3, imprima "Fizz"
//for index in 1...100 {
//    switch ((index % 3) == 0) {
//    case (0==0): //perguntar porque ele precisa desse (0==0)
//        print ("\(index) Fizz")
//    default:
//        print ("\(index)") // perguntar como deixar o defalt vazio
//    }
//}

////Para números divisíveis por 5, imprima “Buzz”
//for index in 1...100 {
//    switch ((index % 5) == 0) {
//    case (0==0): //perguntar porque ele precisa desse (0==0)
//        print ("\(index) Buzz")
//    default:
//        print ("\(index)") // perguntar como deixar o defalt vazio
//    }
//}

// Para números divisíveis por 3 e 5, imprima “FizzBuzz”
//for index in 1...100 {
//    switch ((index % 3) == 0) && ((index % 5) == 0) {
//    case (0==0): //perguntar porque ele precisa desse (0==0)
//        print ("\(index) FizzBuzz")
//    default:
//        print ("\(index)") // perguntar como deixar o defalt vazio
//    }
//}
//

for index in 1 ... 100 {
    switch (index % 3, index % 5) {
    case (0, 0):
        print("\(index) - FizzBuzz")
    case (0, 1):
        print("\(index) - Fizz")
    case (1, 0):
        print("\(index) - Buzz")
    default:
        print(index)
    }
}





/*:
[Anterior](@previous)  |  página 7 of 3
 */
